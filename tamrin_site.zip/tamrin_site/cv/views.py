from django.shortcuts import render

from .models import profile
# Create your views here.

def meow(request):
    number = profile.objects.get(id=1)
    name_list = {
        'prof': number
    }
    return render(request, 'cv/meow.html', name_list)