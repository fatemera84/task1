from django.db import models

# Create your models here.
class profile(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField()
    phone = models.CharField(max_length=50)
    summary = models.TextField()
    skills = models.TextField()
    exprience = models.TextField()
    education = models.TextField()
    def __str__(self):
        return f"{self.name}"
